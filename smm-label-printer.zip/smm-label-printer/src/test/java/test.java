public class test {

    @org.junit.jupiter.api.Test
    void printFunction() {
    }

    @org.junit.jupiter.api.Test
    void start() {
    }

    @org.junit.jupiter.api.Test
    void main() {
    }
}
