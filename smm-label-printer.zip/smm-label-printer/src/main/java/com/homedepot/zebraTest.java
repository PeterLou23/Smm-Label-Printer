package com.homedepot;

import javax.print.*;

import javafx.animation.FadeTransition;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.scene.*;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.util.Duration;

public class zebraTest extends Application{


    @Override
    //javafx set up
    public void start(Stage primaryStage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("zebraGUI.fxml"));
        primaryStage.setTitle("SMM Label Printer");
        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(2), root);
        fadeTransition.setFromValue(0);
        fadeTransition.setToValue(1);
        fadeTransition.setCycleCount(1);
        fadeTransition.play();
        Scene scene = new Scene(root);
        scene.getStylesheets().add("zebra.css");
        primaryStage.setScene(scene);
        primaryStage.show();

    }


    //launching the interface
    public static void main(String args[]) throws PrintException, IOException {
        launch(args);
    }
}
