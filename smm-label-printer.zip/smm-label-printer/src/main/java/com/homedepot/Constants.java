package com.homedepot;

import java.util.HashMap;
import java.util.Map;

public class Constants {
  public static String BC_ZERO_CENTS = "/bc0cents.json.dat";

  public static String BC_ZERO_CENTS_FRIENDLY = "Business Card Cents";
  public static String BC_ZERO_DOLLARS = "/bc0dollars.json.dat";

  public static String BC_ZERO_DOLLARS_FRIENDLY = "Business Card Dollars";
  public static String BIN_ZERO_CENTS = "/bin0cents.json.dat";

  public static String BIN_ZERO_CENTS_FRIENDLY = "Bin Cents";
  public static String BIN_ZERO_DOLLARS = "/bin0dollars.json.dat";

  public static String BIN_ZERO_DOLLARS_FRIENDLY = "Bin Dollars";
  public static String LH_ZERO_CENTS = "/lh0cents.json.dat";

  public static String LH_ZERO_CENTS_FRIENDLY = "Long Hang Cents";
  public static String LH_ZERO_DOLLARS = "/lh0dollars.json.dat";

  public static String LH_ZERO_DOLLARS_FRIENDLY = "Long Hang Dollars";
  public static String PL_ZERO_CENTS = "/pl0cents.json.dat";

  public static String PL_ZERO_CENTS_FRIENDLY = "Pallet Cents";
  public static String PL_ZERO_DOLLARS = "/pl0dollars.json.dat";

  public static String PL_ZERO_DOLLARS_FRIENDLY = "Pallet Dollars";
  public static String SH_ZERO_CENTS = "/sh0cents.json.dat";

  public static String SH_ZERO_CENTS_FRIENDLY = "Short Hang Cents";
  public static String SH_ZERO_DOLLARS = "/sh0dollars.json.dat";

  public static String SH_ZERO_DOLLARS_FRIENDLY = "Short Hang Dollars";
  public static Map<String, String> fileNameMap(){
    Map<String,String> ret = new HashMap<>();
    ret.put(BC_ZERO_CENTS_FRIENDLY, BC_ZERO_CENTS);
    ret.put(BC_ZERO_DOLLARS_FRIENDLY, BC_ZERO_DOLLARS);
    ret.put(BIN_ZERO_CENTS_FRIENDLY, BIN_ZERO_CENTS);
    ret.put(BIN_ZERO_DOLLARS_FRIENDLY, BIN_ZERO_DOLLARS);
    ret.put(LH_ZERO_CENTS_FRIENDLY, LH_ZERO_CENTS);
    ret.put(LH_ZERO_DOLLARS_FRIENDLY, LH_ZERO_DOLLARS);
    ret.put(PL_ZERO_CENTS_FRIENDLY, PL_ZERO_CENTS);
    ret.put(PL_ZERO_DOLLARS_FRIENDLY, PL_ZERO_DOLLARS);
    ret.put(SH_ZERO_CENTS_FRIENDLY, SH_ZERO_CENTS);
    ret.put(SH_ZERO_DOLLARS_FRIENDLY, SH_ZERO_DOLLARS);

    return ret;
  }
  public static String [] getTwoInchFiles() {
    return new String[] {BC_ZERO_CENTS_FRIENDLY, BC_ZERO_DOLLARS_FRIENDLY, BIN_ZERO_CENTS_FRIENDLY, BIN_ZERO_DOLLARS_FRIENDLY, PL_ZERO_CENTS_FRIENDLY, PL_ZERO_DOLLARS_FRIENDLY};
  }

  public static String [] getFourInchFiles() {
    return new String[] {LH_ZERO_CENTS_FRIENDLY, LH_ZERO_DOLLARS_FRIENDLY, SH_ZERO_CENTS_FRIENDLY, SH_ZERO_DOLLARS_FRIENDLY};
  }
}