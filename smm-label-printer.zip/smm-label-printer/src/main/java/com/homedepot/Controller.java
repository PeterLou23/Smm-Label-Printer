package com.homedepot;

import java.io.BufferedReader;
import java.io.InputStream;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javax.print.*;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Base64;
import java.util.ResourceBundle;

import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Shape;
import javafx.scene.text.Text;

public class Controller implements Initializable {


    //Initial variables
    @FXML
    private ComboBox<String> comboBoxFile;
    @FXML
    private ComboBox<String> comboBoxSize;
    @FXML
    private TextField copyAmount;
    @FXML
    private Text fileText;
    @FXML
    private Shape connectionShape;
    @FXML
    private Text printerName;


    private PrintService printerServices = PrintServiceLookup.lookupDefaultPrintService();



    final ObservableList<String> fileSize2 =
            FXCollections.observableArrayList(
                    Constants.getTwoInchFiles()
                    /**
                     "bc0cents",
                     "bc0dollars",
                     "bin0cents",
                     "bin0dollars",
                     "pl0cents",
                     "pl0dollars"
                     **/
            );

    final ObservableList<String> fileSize4 =
            FXCollections.observableArrayList(
                    Constants.getFourInchFiles()
                    /**
                     "lh0cents",
                     "lh0dollars",
                     "sh0cents",
                     "sh0dollars"
                     **/
            );

    ObservableList<String> sizes = FXCollections.observableArrayList("2 INCH", "4 INCH");
    String filePath = "";

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        comboBoxSize.setItems(FXCollections.observableArrayList(sizes));
        connectionShape.setFill(Color.GRAY);
        //comboBoxSize.setOnAction(this:: combox1Change);
    }
    // force the field to be numeric only

    public static String addCopiesToDecodedContents(String contents, int copies) {
        StringBuilder sb = new StringBuilder();
        int start = contents.indexOf("^PW");
        int secondOcc = contents.lastIndexOf("^XZ");
        sb.append(contents, 0, start)
                .append("^MNN^MMC,Y").append(System.lineSeparator())
                .append(contents, start, secondOcc)
                .append("^PQ").append(copies).append(",1,0,Y").append(System.lineSeparator())
                .append(contents, secondOcc, contents.length() - 1);
        return sb.toString();
    }
    private void printAmount(String amount) throws IOException {
//        List<String> fileContent = new ArrayList<>(Files.readAllLines(path, StandardCharsets.UTF_8));
//
//        if(contents.contains("^PQ")) {
//            //Already has the copies command
//            int start = contents.indexOf("^PQ");
//            int end = contents.indexOf(System.lineSeparator(), start);
//
//            sb.append(contents, 0, start - 1);
//            sb.append("^PQ").append(copies).append(",1,0,y");
//            sb.append(contents, end, contents.length()-1);
//        }
//        else {
//            int start = contents.indexOf("^GF");
//            sb.append(contents, 0, start);
//            sb.append("^PQ").append(copies).append(",1,0,y").append(System.lineSeparator());
//            sb.append(contents, start, contents.length()-1);
//        }
//        return sb.toString();
    }

    //print function using file path and converting to bytes then printing in Doc
    @FXML
    private void values() {

        if (comboBoxFile.getSelectionModel().getSelectedItem().equals("bc0cents")) {
            filePath = "/bc0dollars.json.dat";
            System.out.println(filePath + " is in");
        } else if (comboBoxFile.getSelectionModel().getSelectedItem().equals("bc0cents")) {
            filePath = "/bc0cents.json.dat";
            System.out.println(filePath + " is in");
        }
        else if (comboBoxFile.getSelectionModel().getSelectedItem().equals("lh0cents")) {
            filePath = "/ln0cents.json.dat";
            System.out.println(filePath + " is in");
        }
        else if (comboBoxFile.getSelectionModel().getSelectedItem().equals("lh0dollars")) {
            filePath = "/lh0dollars.json.dat";
            System.out.println(filePath + " is in");
        }
        else if (comboBoxFile.getSelectionModel().getSelectedItem().equals("pl0cents")) {
            filePath = "/pl0cents.json.dat";
            System.out.println(filePath + " is in");
        }
        else if (comboBoxFile.getSelectionModel().getSelectedItem().equals("pl0dollars")) {
            filePath = "/pl0dollars.json.dat";
            System.out.println(filePath + " is in");
        }
        else if (comboBoxFile.getSelectionModel().getSelectedItem().equals("sh0cents")) {
            filePath = "/sh0cents.json.dat";
            System.out.println(filePath + " is in");
        }
        else if (comboBoxFile.getSelectionModel().getSelectedItem().equals("sh0dollars")) {
            filePath = "/sh0dollars.json.dat";
            System.out.println(filePath + " is in");
        }
    }

    public String getDecodedContents(String filename) {
        try(InputStream path = getClass().getResourceAsStream(filename)) {
            Base64.Decoder decoder = java.util.Base64.getDecoder();
            String encoded = new String(path.readAllBytes()).replace("\"", "").trim();
            return new String(decoder.decode(encoded));
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Error reading file " + filename);
            alert.show();
            System.out.println("Error reading file " + filename);
            throw new RuntimeException();
        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please finish all the selections");
            alert.show();
            throw new RuntimeException();
        }
    }
    public boolean falseIssues(int num) {
        if (num < 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Can not have a negative number");
            alert.show();
            return true;
        } else if (num > 500) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("Max input 500");
            alert.show();
            return true;
        } else {
            return false;
        }
    }



    @FXML
    private void printFunction() throws PrintException{
        System.out.println(Constants.fileNameMap().get(comboBoxFile.getSelectionModel().getSelectedItem()));
        if ( falseIssues(Integer.parseInt(copyAmount.getText())) == true) {
            return;
        } else {


            try {
                String contentsWithCopies = addCopiesToDecodedContents(getDecodedContents(Constants.fileNameMap().get(comboBoxFile.getSelectionModel().getSelectedItem())),
                        Integer.parseInt(copyAmount.getText()));
                fileText.setText(Constants.fileNameMap().get(comboBoxFile.getSelectionModel().getSelectedItem()));
                DocFlavor docFlavor = DocFlavor.BYTE_ARRAY.AUTOSENSE;
                Doc doc = new SimpleDoc(contentsWithCopies.getBytes(), docFlavor, null);
                DocPrintJob job = printerServices.createPrintJob();
                job.print(doc, null);
            } catch (NumberFormatException e) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Missing or False Input :(");
                alert.show();
                System.out.println("Not a integer");
            }
            System.out.println(Constants.fileNameMap().get(comboBoxFile.getSelectionModel().getSelectedItem()));
        }
    }

    @FXML
    public void checkConnection () throws IOException {
        //Setting up the command
        String command = "powershell.exe Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -match '^USB' }";
        // Executing the command
        Process powerShellProcess = Runtime.getRuntime().exec(command);
        // Getting the results
        powerShellProcess.getOutputStream().close();
        String line;
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader stdout = new BufferedReader(new InputStreamReader(
                powerShellProcess.getInputStream()));
        while ((line = stdout.readLine()) != null) {
            stringBuilder.append(line);
        }
        String connectionInfo = stringBuilder.toString();
        if (connectionInfo.contains("ZDesigner")) {
            connectionShape.setFill(Color.GREEN);
            printerName.setText("Zebra Generic Text Only");
        } else {
            connectionShape.setFill(Color.RED);
            printerName.setText("Not Connected");
        }

    }
    @FXML
    private void comboBoxChange () {
        if (comboBoxSize.getValue().equals("2 INCH")) {
            comboBoxFile.setValue("2 INCH FILES");
            comboBoxFile.setItems(fileSize2);
        } else if (comboBoxSize.getValue().equals("4 INCH")) {
            comboBoxFile.setValue("4 INCH FILES");
            comboBoxFile.setItems(fileSize4);
        }
    }
    public TextField getCopyAmount() {
        return copyAmount;
    }

}