# Store Manager Meeting Label Printer

Create a simple GUI for manager's showcase where thousands of labels are printed. Managers will be able to configure the label information and mass print each label made.

## Architectural Decision Records

-Using JavaFx with SceneBuilder to format the manager's UI. Utilizing
over Swing for a more straight forward and simpler process that offers everything needed.

-JavaFx provides better internet application, connection to other browsers, and easier maintenance.

-SceneBuilder is a simple app to make the UI much easier, and writes JavaFX code


## Architectural Decision Records

### Template

Reference [Markdown ADR Template](https://adr.github.io/madr/)

### Decisions

Troubleshooting
Connectivity

### Installation 

PDF [Instruction](ZPLPrint_Instruction.pdf)
